bibtool -s -d -r bibtool-rules.br -x main.aux bibliography/* > Bibliography.bib
